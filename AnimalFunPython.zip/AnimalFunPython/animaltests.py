import unittest
import animal

class AnimalTests(unittest.TestCase):

    def test_creation_of_an_animal_with_no_parameters(self):
        # Arrange
        expected_result = "I'm an animal called Anonymous and I have 4 limbs and I am 2 years old."

        # Act
        ani = animal.Animal()

        #Assert
        self.assertEqual(str(ani), expected_result)

    def test_negative_limb_count(self):
        # Arrange
        expected_result = "I'm an animal called Anonymous and I have 0 limbs and I am 2 years old."

        # Act
        ani = animal.Animal()
        ani.limb_count = -4

        #Assert
        self.assertEqual(str(ani), expected_result)
        self.assertEqual(ani.limb_count, 0)