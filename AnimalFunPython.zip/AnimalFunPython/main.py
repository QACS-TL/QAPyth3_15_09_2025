import animal
import dog

animals = []
ani1 = animal.Animal("Rover", -10, 2)
animals.append(ani1)

ani2 = animal.Animal()
ani2.name = "Fifi"
ani2.age = 4
#number_of_limbs = input("Please enter the number of limbs")

#ani2.limb_count = number_of_limbs

#ani2.set_limb_count(-1)
#print(ani2.get_limb_count())

ani2.limb_count = -1
print(ani2.limb_count)

animals.append(ani2)

ani3 = animal.Animal()
animals.append(ani3)


fido = dog.Dog()
fido.name = "Rover"
fido.limb_count = 4
fido.age = 6
print(fido.bark(6))

print(fido.eat("bone"))

animals.append(fido)

for ani in animals:
    print(ani.eat("ice cream"))

