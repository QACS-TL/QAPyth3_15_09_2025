class Animal:

    def __init__(self, name="Anonymous", limb_count=4, age=2):
        self.name = name
        self._limb_count = limb_count
        self._age = age

    def eat(self, food):
        return f"I'm an animal called {self.name} eating {food}"

    def set_limb_count(self, limb_count):
        if limb_count < 0:
            limb_count = 0
        self._limb_count = limb_count

    def get_limb_count(self):
        return self._limb_count

    limb_count = property(get_limb_count, set_limb_count)

    @property
    def age(self):
        return self._age

    @age.setter
    def age(self, age):
        if age < 0:
            age = 0
        if age > 200:
            age = 200
        self._age = age

    def __str__(self):
        return f"I'm an animal called {self.name} and I have {self._limb_count} limbs and I am {self.age} years old."