from animal import Animal

class Dog(Animal):

    def bark(self, number_of_times):
        return "Woof " * number_of_times

    def eat(self, food):
        return f"I'm an dog called {self.name} slobber on {food}. Woof Woof."